﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Food_management
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            Sidepanel.Height = button1.Height;
            Sidepanel.Top = button1.Top;
            firstCustControl21.BringToFront();
        }




            private void Form1_Load(object sender, EventArgs e)
            {

            }

            private void label1_Click(object sender, EventArgs e)
            {

            }

            private void button1_Click(object sender, EventArgs e)
            {
            Sidepanel.Height = button1.Height;
            Sidepanel.Top = button1.Top;
            firstCustControl21.BringToFront();

            }

        private void button2_Click(object sender, EventArgs e)
        {
            Sidepanel.Height = button2.Height;
            Sidepanel.Top = button2.Top;
            secondCustControl21.BringToFront();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Sidepanel.Height = button4.Height;
            Sidepanel.Top = button4.Top;
            
            DialogResult result = MessageBox.Show("Are you sure you wish to quit?", "Exit Application", MessageBoxButtons.YesNo);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                Application.Exit();
            }
        }


        
        private void secondCustControl21_Load(object sender, EventArgs e)
        {
            
        }

        

        
    }
    }

