﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Food_management
{
    public partial class Form2 : Form
    {

       

        public Form2()
        {
            InitializeComponent();
           
        }

        

        private void button1_Click(object sender, EventArgs e)

        {//===========for Form3=================
            UserInformation f3 = new UserInformation();
            f3.Show();
            Form2 mealForm = new Form2();
            this.Close();
           


        }

       // I use a function for control(rest)  all textBoxes ======= Rest TextBoxes=====
       private void ContTextBoxes()
        {
            Action<Control.ControlCollection> restFunc = null;
            restFunc = (controls) =>
              {
                  foreach (Control control in controls)
                      if (control is TextBox)
                          (control as TextBox).Text = "0";
                      else
                          restFunc(control.Controls);
              };
            restFunc(Controls);
        }
        // I use a function for control(rest)  all checkBoxes=====Rest CheckBoxes====
        private void ContCheckBoxes()
        {
            Action<Control.ControlCollection> restFunc = null;
            restFunc = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is CheckBox)
                        (control as CheckBox).Checked=false;
                    else
                        restFunc(control.Controls);
            };
            restFunc(Controls);
        }

        //========Enable all TextBoxes========
        private void EnabledTextBoxes()
        {
            Action<Control.ControlCollection> restFunc = null;
            restFunc = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Enabled = false;
                    else
                        restFunc(control.Controls);
            };
            restFunc(Controls);
        }
       

        // Rest button
        private void button3_Click(object sender, EventArgs e)
        {
            ContTextBoxes();
            ContCheckBoxes();
            cmbPaayMet.Text=" ";
            btNext.Enabled = false;
        }
       
        //========Cost of Meals (Calculate Total)=========================)
        public void button2_Click(object sender, EventArgs e)
        {

            Main_fastFood_Menu CostOfMeals = new Main_fastFood_Menu();

            CostOfMeals.ChickenBurger = Convert.ToDouble(textBox1.Text);
            CostOfMeals.BigKing = CostOfMeals.BigKing_Price * Double.Parse(textBox2.Text);
            CostOfMeals.RodeoWhopper = CostOfMeals.RodeoWhopper_Price * Double.Parse(textBox3.Text);
            CostOfMeals.BurgerKingWhopper = CostOfMeals.BurgerKingWhopper_Price * Double.Parse(textBox4.Text);
            CostOfMeals.BigMac = CostOfMeals.BigMac_Price * Double.Parse(textBox5.Text);
            CostOfMeals.Cheeseburger = CostOfMeals.Cheeseburger_Price * Double.Parse(textBox6.Text);
            CostOfMeals.WhopperMenu = CostOfMeals.WhopperMenu_Price * Double.Parse(textBox7.Text);
            CostOfMeals.TripleWhopperMenu = CostOfMeals.TripleWhopperMenu_Price * Double.Parse(textBox8.Text);
            CostOfMeals.ClassicBurger = CostOfMeals.ClassicBurger_Price * Double.Parse(textBox20.Text);

            CostOfMeals.Chocolate = CostOfMeals.Chocolate_Price * Double.Parse(textBox9.Text);
            CostOfMeals.HashBrown = CostOfMeals.HashBrown_Price * Double.Parse(textBox10.Text);
            CostOfMeals.Pancakes = CostOfMeals.Pancakes_Price * Double.Parse(textBox17.Text);
            CostOfMeals.PineappleStick = CostOfMeals.PineappleStick_Price * Double.Parse(textBox18.Text);
            CostOfMeals.ToastedBagel = CostOfMeals.ToastedBagel_Price * Double.Parse(textBox19.Text);

            CostOfMeals.Tea = CostOfMeals.Tea_Price * Double.Parse(textBox26.Text);
            CostOfMeals.Cola = CostOfMeals.Cola_Price * Double.Parse(textBox25.Text);
            CostOfMeals.Orange = CostOfMeals.Orange_Price * Double.Parse(textBox16.Text);
            CostOfMeals.IcedTea = CostOfMeals.IcedTea_Price * Double.Parse(textBox14.Text);
            CostOfMeals.BottleWater = CostOfMeals.BottleWater_Price * Double.Parse(textBox15.Text);

            CostOfMeals.Cappuccino = CostOfMeals.Cappuccino_Price * Double.Parse(textBox13.Text);
            CostOfMeals.Latte = CostOfMeals.Latte_Price * Double.Parse(textBox12.Text);
            CostOfMeals.HotChocolate = CostOfMeals.HotChocolate_Price * Double.Parse(textBox11.Text);
            CostOfMeals.DoubleEspresso = CostOfMeals.DoubleEspresso_Price * Double.Parse(textBox30.Text);

            CostOfMeals.Mocha = CostOfMeals.Mocha_Price * Double.Parse(textBox27.Text);
            CostOfMeals.Americano = CostOfMeals.Americano_Price * Double.Parse(textBox29.Text);
            CostOfMeals.TurkishCoffee = CostOfMeals.TurkishCoffee_Price * Double.Parse(textBox30.Text);


            double subTotal;

            //==================Total sum======================
            subTotal = CostOfMeals.GetAmount();
            textBSubTotal.Text = Convert.ToString(subTotal);
            textBSubTotal.Text = String.Format("{0:C}", subTotal);
            //STRING//
            //============Cost of Meal, Desserts,Drinks and Coffee=================

            string itemcost1 = String.Format("{0:C}", CostOfMeals.itemcost1);
            txtMeals.Text = (itemcost1);

            string itemcost2 = String.Format("{0:C}", CostOfMeals.itemcost2);
            txtDesserts.Text = (itemcost2);

            string itemcost3 = String.Format("{0:C}", CostOfMeals.itemcost3);
            txtDrinks.Text = (itemcost3);

            string itemcost4 = String.Format("{0:C}", CostOfMeals.itemcost4);
            txtCoffee.Text = (itemcost4);
            btNext.Enabled = true;

        }

        private void Form2_Load(object sender, EventArgs e)
        {
           //===========Array===============
           btNext.Enabled =false;
            //for payment method (ComboBox)
            string[] payMet = { "Cash", "Visa Card", "Master Card", "Debit Card" };
            cmbPaayMet.Items.AddRange(payMet);
           
            EnabledTextBoxes();


        }

        //============ Select Meal panel=======================
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked==true)
            {
                textBox1.Enabled=true;
                textBox1.Text = "";
                textBox1.Focus();
            }
            else
            {
                textBox1.Enabled = false;
                textBox1.Text = "0";
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
            {
                textBox2.Enabled = true;
                textBox2.Text = "";
                textBox1.Focus();
            }
            else
            {
                textBox2.Enabled = false;
                textBox2.Text = "0";
            }
        }
        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked == true)
            {
                textBox3.Enabled = true;
                textBox3.Text = "";
                textBox3.Focus();
            }
            else
            {
                textBox3.Enabled = false;
                textBox3.Text = "0";
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked == true)
            {
                textBox4.Enabled = true;
                textBox4.Text = "";
                textBox4.Focus();
            }
            else
            {
                textBox4.Enabled = false;
                textBox4.Text = "0";
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked == true)
            {
                textBox5.Enabled = true;
                textBox5.Text = "";
                textBox5.Focus();
            }
            else
            {
                textBox5.Enabled = false;
                textBox5.Text = "0";
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked == true)
            {
                textBox6.Enabled = true;
                textBox6.Text = "";
                textBox6.Focus();
            }
            else
            {
                textBox6.Enabled = false;
                textBox6.Text = "0";
            }
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox7.Checked == true)
            {
                textBox7.Enabled = true;
                textBox7.Text = "";
                textBox7.Focus();
            }
            else
            {
                textBox7.Enabled = false;
                textBox7.Text = "0";
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox8.Checked == true)
            {
                textBox8.Enabled = true;
                textBox8.Text = "";
                textBox8.Focus();
            }
            else
            {
                textBox8.Enabled = false;
                textBox8.Text = "0";
            }

        }
   
        private void checkBox26_CheckedChanged(object sender, EventArgs e)
        {

            if (checkBox26.Checked == true)
            {
                textBox20.Enabled = true;
                textBox20.Text = "";
                textBox20.Focus();
            }
            else
            {
                textBox20.Enabled = false;
                textBox20.Text = "0";
            }
        }
        //============Desserts panel================
        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox9.Checked == true)
            {
                textBox9.Enabled = true;
                textBox9.Text = "";
                textBox9.Focus();
            }
            else
            {
                textBox9.Enabled = false;
                textBox9.Text = "0";
            }
        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox10.Checked == true)
            {
                textBox10.Enabled = true;
                textBox10.Text = "";
                textBox10.Focus();
            }
            else
            {
                textBox10.Enabled = false;
                textBox10.Text = "0";
            }
        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox11.Checked == true)
            {
                textBox17.Enabled = true;
                textBox17.Text = "";
                textBox17.Focus();
            }
            else
            {
                textBox17.Enabled = false;
                textBox17.Text = "0";
            }
        }

        private void checkBox13_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox13.Checked == true)
            {
                textBox18.Enabled = true;
                textBox18.Text = "";
                textBox18.Focus();
            }
            else
            {
                textBox18.Enabled = false;
                textBox18.Text = "0";
            }
        }

        private void checkBox14_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox14.Checked == true)
            {
                textBox19.Enabled = true;
                textBox19.Text = "";
                textBox19.Focus();
            }
            else
            {
                textBox19.Enabled = false;
                textBox19.Text = "0";
            }

        }
        // ===================Drinks panel===============
        private void checkBox21_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox21.Checked == true)
            {
                textBox26.Enabled = true;
                textBox26.Text = "";
                textBox26.Focus();
            }
            else
            {
                textBox26.Enabled = false;
                textBox26.Text = "0";
            }
        }

        private void checkBox20_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox20.Checked == true)
            {
                textBox25.Enabled = true;
                textBox25.Text = "";
                textBox25.Focus();
            }
            else
            {
                textBox25.Enabled = false;
                textBox25.Text = "0";
            }
        }

        private void checkBox19_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox19.Checked == true)
            {
                textBox16.Enabled = true;
                textBox16.Text = "";
                textBox16.Focus();
            }
            else
            {
                textBox16.Enabled = false;
                textBox16.Text = "0";
            }
        }

        private void checkBox17_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox17.Checked == true)
            {
                textBox14.Enabled = true;
                textBox14.Text = "";
                textBox14.Focus();
            }
            else
            {
                textBox14.Enabled = false;
                textBox14.Text = "0";
            }
        }

        private void checkBox18_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox18.Checked == true)
            {
                textBox15.Enabled = true;
                textBox15.Text = "";
                textBox15.Focus();
            }
            else
            {
                textBox15.Enabled = false;
                textBox15.Text = "0";
            }
        }
        //  ==============Coffee panel=============
        private void checkBox16_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox16.Checked == true)
            {
                textBox13.Enabled = true;
                textBox13.Text = "";
                textBox13.Focus();
            }
            else
            {
                textBox13.Enabled = false;
                textBox13.Text = "0";
            }
        }

        private void checkBox15_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox15.Checked == true)
            {
                textBox12.Enabled = true;
                textBox12.Text = "";
                textBox12.Focus();
            }
            else
            {
                textBox12.Enabled = false;
                textBox12.Text = "0";
            }
        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox12.Checked == true)
            {
                textBox11.Enabled = true;
                textBox11.Text = "";
                textBox11.Focus();
            }
            else
            {
                textBox11.Enabled = false;
                textBox11.Text = "0";
            }
        }

        private void checkBox22_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox22.Checked == true)
            {
                textBox27.Enabled = true;
                textBox27.Text = "";
                textBox27.Focus();
            }
            else
            {
                textBox27.Enabled = false;
                textBox27.Text = "0";
            }
        }

        private void checkBox23_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox23.Checked == true)
            {
                textBox28.Enabled = true;
                textBox28.Text = "";
                textBox28.Focus();
            }
            else
            {
                textBox28.Enabled = false;
                textBox28.Text = "0";
            }
        }
        //===========pay method (Cash)==========
        private void cmbPayMet_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void checkBox24_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox24.Checked == true)
            {
                textBox29.Enabled = true;
                textBox29.Text = "";
                textBox29.Focus();
            }
            else
            {
                textBox29.Enabled = false;
                textBox29.Text = "0";
            }
        }

        private void checkBox25_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox25.Checked == true)
            {
                textBox30.Enabled = true;
                textBox30.Text = "";
                textBox30.Focus();
            }
            else
            {
                textBox30.Enabled = false;
                textBox30.Text = "0";
            }
        }
        // ===== for all textboxes=========
        private void Only_Numbers(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
            }
        }

        private void textBox23_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
