﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Food_management
{
    class Price 
    {


        //public static Form2 form2;

        //public static void SetForm(Form2 form)
        //{
        //    form2 = form;
        //}


        ////==========Hamburger Price=============
        //public double ChickenBurger_Price = 16.34;
        //public double BigKing_Price = 20.12;
        //public double RodeoWhopper_Price = 22.10;
        //public double BurgerKingWhopper_Price = 25.92;
        //public double BigMac_Price = 23.94;
        //public double Cheeseburger_Price = 20;
        //public double WhopperMenu_Price = 32.95;
        //public double TripleWhopperMenu_Price = 35.12;
        //public double ClassicBurger_Price = 15;
        ////======== Desserts Price===============
        //public double Chocolate_Price = 15.09;
        //public double HashBrown_Price = 22.98;
        //public double Pancakes_Price = 30;
        //public double PineappleStick_Price = 33.78;
        //public double ToastedBagel_Price = 35.98;
        ////==========Drinks Price=============
        //public double Tea_Price = 5.17;
        //public double Cola_Price = 10.99;
        //public double Orange_Price = 19.50;
        //public double IcedTea_Price = 12.50;
        //public double BottleWater_Price = 3.12;
        ////==========Coffee Price==============
        //public double Cappuccino_Price = 33.23;
        //public double Latte_Price = 28.10;
        //public double HotChocolate_Price = 30.99;
        //public double Mocha_Price = 36.15;
        //public double DoubleEspresso_Price = 29.95;
        //public double Americano_Price = 33.15;
        //public double TurkishCoffee_Price = 31.12;


        

        //public double itemcost;
        //public double itemcost1;
        //public double itemcost2;
        //public double itemcost3;
        //public double itemcost4;


        ////Form2 form2 = new Form2();
        //public double GetAmount()
        //{

        //    Main_fastFood_Menu CostItm = new Main_fastFood_Menu();
        //    ChickenBurger = ChickenBurger_Price * Double.Parse(form2.textBox1.Text);
        //    BigKing = BigKing_Price * Double.Parse(form2.textBox2.Text);
        //    RodeoWhopper = RodeoWhopper_Price * Double.Parse(form2.textBox3.Text);
        //    BurgerKingWhopper = BurgerKingWhopper_Price * Double.Parse(form2.textBox4.Text);
        //    BigMac = BigMac_Price * Double.Parse(form2.textBox5.Text);
        //    Cheeseburger = Cheeseburger_Price * Double.Parse(form2.textBox6.Text);
        //    WhopperMenu = WhopperMenu_Price * Double.Parse(form2.textBox7.Text);
        //    TripleWhopperMenu = TripleWhopperMenu_Price * Double.Parse(form2.textBox8.Text);
        //    ClassicBurger = ClassicBurger_Price * Double.Parse(form2.textBox20.Text);

        //    CostItm.Chocolate = Chocolate_Price * Double.Parse(form2.textBox9.Text);
        //    CostItm.HashBrown = HashBrown_Price * Double.Parse(form2.textBox10.Text);
        //    CostItm.Pancakes = Pancakes_Price * Double.Parse(form2.textBox17.Text);
        //    CostItm.PineappleStick = PineappleStick_Price * Double.Parse(form2.textBox18.Text);
        //    CostItm.ToastedBagel = ToastedBagel_Price * Double.Parse(form2.textBox19.Text);

        //    CostItm.Tea = Tea_Price * Double.Parse(form2.textBox26.Text);
        //    CostItm.Cola = Cola_Price * Double.Parse(form2.textBox25.Text);
        //    CostItm.Orange = Orange_Price * Double.Parse(form2.textBox16.Text);
        //    CostItm.IcedTea = IcedTea_Price * Double.Parse(form2.textBox14.Text);
        //    CostItm.BottleWater = BottleWater_Price * Double.Parse(form2.textBox15.Text);


        //    CostItm.Cappuccino = Cappuccino_Price * Double.Parse(form2.textBox13.Text);
        //    CostItm.Latte = Latte_Price * Double.Parse(form2.textBox12.Text);
        //    CostItm.HotChocolate = HotChocolate_Price * Double.Parse(form2.textBox11.Text);
        //    CostItm.Mocha = Mocha_Price * Double.Parse(form2.textBox27.Text);
        //    CostItm.DoubleEspresso = DoubleEspresso_Price * Double.Parse(form2.textBox28.Text);
        //    CostItm.Americano = Americano_Price * Double.Parse(form2.textBox29.Text);
        //    CostItm.TurkishCoffee = TurkishCoffee_Price * Double.Parse(form2.textBox30.Text);



        //    itemcost1 = CostItm.ChickenBurger + CostItm.BigKing + CostItm.RodeoWhopper + CostItm.BurgerKingWhopper
        //                   + CostItm.BigMac + CostItm.Cheeseburger + CostItm.WhopperMenu + CostItm.TripleWhopperMenu + CostItm.ClassicBurger;
        //    itemcost2 = CostItm.Chocolate + CostItm.HashBrown + CostItm.Pancakes + CostItm.PineappleStick + CostItm.ToastedBagel;
        //    itemcost3 = CostItm.Tea + CostItm.Cola + CostItm.Orange + CostItm.IcedTea + CostItm.BottleWater;
        //    itemcost4 = CostItm.Cappuccino + CostItm.Latte + CostItm.HotChocolate + CostItm.Mocha + CostItm.DoubleEspresso + CostItm.Americano + CostItm.TurkishCoffee;
        //    itemcost = itemcost1 + itemcost2 + itemcost3 + itemcost4;
        //    return itemcost;


        //    //    public double GetAmount() {
        //    //    Calculate();
        //    //itemcost1 = ChickenBurger + BigKing + RodeoWhopper + BurgerKingWhopper + BigMac + Cheeseburger + WhopperMenu + TripleWhopperMenu + ClassicBurger;
        //    //        itemcost2 = Chocolate + HashBrown + Pancakes + PineappleStick + ToastedBagel;
        //    //        itemcost3 = Tea + Cola + Orange + IcedTea + BottleWater;
        //    //        itemcost4 = Cappuccino + Latte + HotChocolate + Mocha + DoubleEspresso + Americano + TurkishCoffee;

        //    //        itemcost = itemcost1 + itemcost2 + itemcost3 + itemcost4;
        //    //        return itemcost;
        //}
}
    }
