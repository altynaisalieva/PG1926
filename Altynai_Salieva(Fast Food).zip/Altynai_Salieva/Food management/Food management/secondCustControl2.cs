﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Food_management
{
    public partial class secondCustControl : UserControl
    {
        public secondCustControl()
        {
            InitializeComponent();
        }

        //Form2 f2;
        private void button1_Click(object sender, EventArgs e)
        {
            //if (f2 == null)
            //{
            //    f2 = new Form2();
            //    f2.Show();
            //}
            //else
            //    f2.Activate();
            Form2 f2 = new Form2();
            f2.Show();

        }
    }
}
