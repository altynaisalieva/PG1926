﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Food_management
{
    public partial class UserInformation : Form
    {
        public UserInformation()
        {
            InitializeComponent();
        }

       
        //==================Exit from userInformationpage ===========================
        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to leave this page ?", "Exit of Select Meal page", MessageBoxButtons.YesNo);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                Close();
            }
        }

       
        //=======Customer Information======
        private void button1_Click(object sender, EventArgs e)
        {
            UserInfo CustomerInfo = new UserInfo();
            CustomerInfo.Name = textBox1.Text;
            CustomerInfo.Surname = textBox2.Text;
            CustomerInfo.Address = textBox3.Text;
            CustomerInfo.CardNum = txtCardnum.Text;
            CustomerInfo.Phone = textBox4.Text;

            

            if (String.IsNullOrWhiteSpace(textBox1.Text) ||
                String.IsNullOrWhiteSpace(textBox2.Text) ||
                String.IsNullOrWhiteSpace(textBox3.Text) || 
                CustomerInfo.Phone.Length !=11)



            {
                MessageBox.Show("All fields must to filled or check that your number is correct!");

            }
                else
                {
                DateTime today = DateTime.Now;
                    DateTime newDate = today.AddMinutes(30);
                    MessageBox.Show("It will be delivered approximately at(30 min)" +"\n"+ newDate.ToString("f"), "Thank you!! Your order is accepted");
            }
           
            lbName.Text = CustomerInfo.Name;
            lbSurname.Text = CustomerInfo.Surname;
            lbAddress.Text = CustomerInfo.Address;
            LbTel.Text = Convert.ToString(CustomerInfo.Phone);

        }
       

        private void OnlyNumber(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!char.IsDigit(ch) && ch != 8 )
            {
                e.Handled = true;
              
            }
        }
    }
}
