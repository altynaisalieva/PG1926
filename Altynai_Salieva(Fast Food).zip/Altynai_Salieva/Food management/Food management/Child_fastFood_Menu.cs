﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Food_management
{
    class Child_fastFood_Menu : Main_fastFood_Menu
    {
        

        
    }
}
