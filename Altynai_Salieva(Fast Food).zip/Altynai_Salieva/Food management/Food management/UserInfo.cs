﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Food_management
{
    class UserInfo
    {  //========Customer information class=====
        private string name;
        private string surname;
        private string address;
        private string cardNum;
        private string phone;


        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Surname
        {
            get { return surname.ToUpper(); }
            set { surname = value; }
        }

        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        public string CardNum
        {
            get { return cardNum; }
            set { cardNum = value; }
        }

        public string Phone
        {
            get { return phone; }
            set
            {
                phone = value; }
           
        }


    }
    }


