﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Food_management
{
    class Main_fastFood_Menu
    {
      

        public double ChickenBurger;
        public double BigKing;
        public double RodeoWhopper;
        public double BurgerKingWhopper;
        public double BigMac;
        public double Cheeseburger;
        public double WhopperMenu;
        public double TripleWhopperMenu;
        public double ClassicBurger;

        public double Chocolate;
        public double HashBrown;
        public double Pancakes;
        public double PineappleStick;
        public double ToastedBagel;


        public double Tea;
        public double Cola;
        public double Orange;
        public double IcedTea;
        public double BottleWater;

        public double Cappuccino;
        public double Latte;
        public double HotChocolate;
        public double Mocha;
        public double DoubleEspresso;
        public double Americano;
        public double TurkishCoffee;

        public double itemcost;
        public double itemcost1;
        public double itemcost2;
        public double itemcost3;
        public double itemcost4;



        //==========Hamburger Price=============
        public double ChickenBurger_Price = 16.34;
        public double BigKing_Price = 20.12;
        public double RodeoWhopper_Price = 22.10;
        public double BurgerKingWhopper_Price = 25.92;
        public double BigMac_Price = 23.94;
        public double Cheeseburger_Price = 20;
        public double WhopperMenu_Price = 32.95;
        public double TripleWhopperMenu_Price = 35.12;
        public double ClassicBurger_Price = 15;
        //======== Desserts Price===============
        public double Chocolate_Price = 15.09;
        public double HashBrown_Price = 22.98;
        public double Pancakes_Price = 30;
        public double PineappleStick_Price = 33.78;
        public double ToastedBagel_Price = 35.98;
        //==========Drinks Price=============
        public double Tea_Price = 5.17;
        public double Cola_Price = 10.99;
        public double Orange_Price = 19.50;
        public double IcedTea_Price = 12.50;
        public double BottleWater_Price = 3.12;
        //==========Coffee Price==============
        public double Cappuccino_Price = 33.23;
        public double Latte_Price = 28.10;
        public double HotChocolate_Price = 30.99;
        public double Mocha_Price = 36.15;
        public double DoubleEspresso_Price = 29.95;
        public double Americano_Price = 33.15;
        public double TurkishCoffee_Price = 31.12;

        public double GetAmount()
        {

            itemcost1 = ChickenBurger + BigKing + RodeoWhopper + BurgerKingWhopper + BigMac + Cheeseburger + WhopperMenu + TripleWhopperMenu + ClassicBurger;
            itemcost2 = Chocolate + HashBrown + Pancakes + PineappleStick + ToastedBagel;
            itemcost3 = Tea + Cola + Orange + IcedTea + BottleWater;
            itemcost4 = Cappuccino + Latte + HotChocolate + Mocha + DoubleEspresso + Americano + TurkishCoffee;

            itemcost = itemcost1 + itemcost2 + itemcost3 + itemcost4;
            return itemcost;

        }
    }
}