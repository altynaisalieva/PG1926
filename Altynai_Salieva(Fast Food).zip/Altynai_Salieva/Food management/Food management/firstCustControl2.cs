﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Food_management
{
    public partial class firstCustControl : UserControl
    {
        public firstCustControl()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            const string message = "If you have questions or complaints then you can call or send email. " +"\r\n" 
                                 + "Email address: fast_food@gmail.com" + "\r\n"+
                                   "Cell phone: 05559007898";
            const string caption = "Form Closing";
            MessageBox.Show(message, caption ,
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Question);

        }
    }
}
